<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Meta_Factory' );


	class Tribe_Meta_Factory extends Tribe__Events__Meta_Factory {

	}